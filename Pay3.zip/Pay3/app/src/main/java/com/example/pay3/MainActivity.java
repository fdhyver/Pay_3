package com.example.pay3;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    //uses the private variable Button to Check for the button for the next activity
    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //calls the super class on Create to create a saving instance
        super.onCreate(savedInstanceState);
        //sets the Layout of the rendering on page 2 of the app
        setContentView(R.layout.activity_main);
        //sets the image viewer for the app with image view
        ImageView myImageView = findViewById(R.id.imageView1);
        //sets the image called pay1 for the user to see
        myImageView.setImageResource(R.drawable.total);
        //uses the variable button to find the component button called btn1
        button = (Button) findViewById(R.id.btn1);
// sets the onClickListener to listen for the action of clicking the button and call intent for being able to open Activity 2 and 3 from the Main activity being the parent Activity.
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // open activity commands are set from the parent activity to open activity 2 and activity 3
                { openActivity3 ();}
                openActivity2();
            }
        });
    }

    //sets up the Activity reference for Activity 3
    public void openActivity3() {
        Intent intent = new Intent(this, Activity3.class);
        startActivity(intent);
    }
    // Sets up the activity reference from the parent perspective to start the intent when called on the local activity.
    public void openActivity2() {
        Intent intent = new Intent(this, Activity2.class);
        startActivity(intent);
    }

}
