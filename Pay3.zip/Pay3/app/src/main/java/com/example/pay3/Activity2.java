package com.example.pay3;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.widget.TextView;
import android.widget.Toast;



import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.gms.wallet.PaymentsClient;
import com.google.android.gms.wallet.Wallet;
import com.google.android.gms.wallet.WalletConstants;

//Pulls from the Activity 2 class
public class Activity2 extends AppCompatActivity {
    //uses the private variable Button to Check for the button for the next activity
    private Button button;
    private PaymentsClient paymentsClient;

    @Override
    //checks the instance of the continue activity button
    protected void onCreate(Bundle savedInstanceState) {
        //calls the super class on Create to create a saving instance
        super.onCreate(savedInstanceState);
        //sets the Layout of the rendering on page 2 of the app
     Wallet.WalletOptions walletOptions =
             new Wallet.WalletOptions.Builder()
             .setEnvironment(WalletConstants.ENVIRONMENT_TEST)
             .build();
     paymentsClient = Wallet.getPaymentsClient(
             this, walletOptions);


        //uses the variable button to find the component button called btn2
        button = (Button) findViewById(R.id.btn2);
        // sets the onClickListener to listen for the action of clicking the button and call intent for Activity3
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                openActivity3();
            }
        });
    }

    // Intent is called and used to open the new activity or page and close the previous page or activity.
    public void openActivity3() {
        //Intent calls the Activity 3 class to open the Activity with its xml Layout.
        Intent intent = new Intent(this, Activity3.class);
        //calls to start the following activity.
        startActivity(intent);
    }

}

